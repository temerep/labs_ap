package com.repei.droidbattle.droid;
public class Knight extends BaseDroid{
  public Knight(String name) {
    super(240, 35, name, "Knight");
  }
}
