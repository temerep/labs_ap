package com.repei.droidbattle.droid;
public class Wizard extends BaseDroid{
  public Wizard(String name) {
    super(180, 45, name, "Wizard");
  }

}
