package com.repei.droidbattle.droid;
public class Bowman extends BaseDroid {
  public Bowman(String name) {
    super(120, 25, name, "Bowman");
  }
}
